/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bloodbank;

/**
 *
 * @author LENOVO
 */
public class BloodBank {

    public static void main(String[] args) {
       
    }
}
